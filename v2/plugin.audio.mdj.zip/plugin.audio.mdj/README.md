The audio version of this plugin
